// Global State
const state = {
  dbStats: null,
  collections: [],
  activeCollection: 'students',
  currentTab: 'excel-reports',
  activeReportType: 'consolidated-matrix',
  activeReportData: [],
  documents: [],
  page: 1,
  limit: 20,
  totalDocs: 0,
  totalPages: 1,
  currentView: 'table',
  schemaData: null,
  charts: {}
};

// DOM Initialization
document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) lucide.createIcons();

  initNavigation();
  initModals();
  initToolbar();

  fetchConnectionState();
  loadOverviewStats();
  loadCollectionsList().then(() => {
    // Automatically preview Consolidated Matrix report on load
    previewReport('consolidated-matrix');
  });
});

// 1. Connection & State Fetching
async function fetchConnectionState() {
  try {
    const res = await fetch('/api/db/stats');
    const data = await res.json();
    state.dbStats = data;

    const statusDot = document.getElementById('statusDot');
    const statusText = document.getElementById('statusText');
    const modeTag = document.getElementById('modeTag');

    if (data.mode === 'LIVE_MONGODB') {
      statusDot.className = 'status-dot online';
      statusText.textContent = `Connected to ${data.dbName}`;
      modeTag.className = 'mode-tag live';
      modeTag.textContent = 'LIVE MONGO';
    } else {
      statusDot.className = 'status-dot pulsing';
      statusText.textContent = `Sandbox Demo (${data.dbName})`;
      modeTag.className = 'mode-tag';
      modeTag.textContent = 'SANDBOX';
    }
  } catch (err) {
    console.error('Error fetching connection state:', err);
  }
}

// 2. Load Overview Stats
async function loadOverviewStats() {
  try {
    const res = await fetch('/api/db/stats');
    const data = await res.json();
    state.dbStats = data;

    document.getElementById('statCollections').textContent = data.collectionsCount || '0';
    document.getElementById('statDocuments').textContent = (data.documentsCount || 0).toLocaleString();
    document.getElementById('statDataSize').textContent = `${data.dataSizeMB} MB`;
    document.getElementById('sidebarDbName').textContent = data.dbName || 'brdp_portal';
  } catch (err) {
    console.error('Error loading overview stats:', err);
  }
}

// 3. Load Collections List
async function loadCollectionsList() {
  try {
    const res = await fetch('/api/collections');
    const data = await res.json();
    state.collections = data.collections || [];

    renderSidebarCollections();
    populateCollectionSelects();
  } catch (err) {
    console.error('Error loading collections:', err);
  }
}

function renderSidebarCollections() {
  const container = document.getElementById('sidebarCollectionList');
  if (!container) return;

  container.innerHTML = state.collections.map(c => `
    <div class="coll-item ${c.name === state.activeCollection ? 'active' : ''}" onclick="selectCollection('${c.name}')">
      <span><i data-lucide="folder" style="width:14px; height:14px; vertical-align:middle; margin-right:4px;"></i> ${c.name}</span>
      <span class="coll-count">${c.count}</span>
    </div>
  `).join('');

  if (window.lucide) lucide.createIcons();
}

function populateCollectionSelects() {
  ['schemaCollectionSelect', 'explorerCollectionSelect'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.innerHTML = state.collections.map(c => `
        <option value="${c.name}" ${c.name === state.activeCollection ? 'selected' : ''}>${c.name} (${c.count})</option>
      `).join('');
    }
  });
}

function selectCollection(collName) {
  state.activeCollection = collName;
  renderSidebarCollections();
  populateCollectionSelects();
  loadSchemaForCollection(collName);
  loadExplorerDocuments(collName, 1);
}

// ─────────────────────────────────────────────
// EXCEL REPORTS GENERATION & PREVIEW ENGINE
// ─────────────────────────────────────────────

async function previewReport(reportType) {
  state.activeReportType = reportType;
  const header = document.getElementById('reportPreviewHeader');
  const body = document.getElementById('reportPreviewBody');
  const title = document.getElementById('reportPreviewTitle');

  const titles = {
    'students': 'Student Master Data Report Preview',
    'semester-fees': 'Semester-Wise Fee Breakdown Report Preview',
    'consolidated-matrix': 'Consolidated Student-Wise & Semester-Wise Fee Matrix Report Preview'
  };

  title.innerHTML = `<i data-lucide="table" class="header-inline-icon"></i> ${titles[reportType] || 'Report Data Preview'}`;
  body.innerHTML = '<tr><td colspan="10" class="text-muted p-4 text-center">Fetching report data...</td></tr>';

  try {
    const res = await fetch(`/api/reports/${reportType}`);
    const data = await res.json();

    state.activeReportData = data.data || [];

    if (reportType === 'students') {
      document.getElementById('badgeStudentCount').textContent = `${data.count} Students`;
    } else if (reportType === 'semester-fees') {
      document.getElementById('badgeLedgerCount').textContent = `${data.count} Ledgers`;
    }

    if (state.activeReportData.length === 0) {
      header.innerHTML = '<th>No Data</th>';
      body.innerHTML = '<tr><td class="text-muted p-4 text-center">No records available for this report.</td></tr>';
      return;
    }

    // Render Preview Table
    const cols = Object.keys(state.activeReportData[0]);
    header.innerHTML = cols.map(c => `<th>${c}</th>`).join('');

    body.innerHTML = state.activeReportData.slice(0, 50).map(row => `
      <tr>
        ${cols.map(c => {
          const val = row[c];
          let formatted = typeof val === 'number' ? val.toLocaleString('en-IN') : String(val);
          let badgeClass = '';
          if (c.includes('Pending') && typeof val === 'number' && val > 0) badgeClass = 'text-amber font-bold';
          if (c === 'Fee Status' || c === 'Overall Status') {
            if (val === 'PAID') badgeClass = 'badge badge-success';
            else if (val === 'PARTIAL') badgeClass = 'badge badge-accent';
            else badgeClass = 'badge badge-outline text-danger';
          }
          return `<td class="${badgeClass}">${formatted}</td>`;
        }).join('')}
      </tr>
    `).join('');

    if (window.lucide) lucide.createIcons();
  } catch (err) {
    console.error('Error previewing report:', err);
    body.innerHTML = `<tr><td colspan="10" class="text-danger p-4 text-center">Failed to load report: ${err.message}</td></tr>`;
  }
}

// Download Excel File using SheetJS
async function exportToExcel(reportType) {
  try {
    let data = state.activeReportData;
    if (state.activeReportType !== reportType || !data || data.length === 0) {
      const res = await fetch(`/api/reports/${reportType}`);
      const json = await res.json();
      data = json.data || [];
    }

    if (!data || data.length === 0) {
      alert('No data available to export to Excel.');
      return;
    }

    // Generate SheetJS Worksheet
    const worksheet = XLSX.utils.json_to_sheet(data);

    // Auto-fit column widths
    const colWidths = Object.keys(data[0]).map(key => ({
      wch: Math.max(key.length + 3, 15)
    }));
    worksheet['!cols'] = colWidths;

    // Create workbook & append worksheet
    const workbook = XLSX.utils.book_new();
    const sheetName = reportType === 'students' ? 'Student Master Data' :
                     reportType === 'semester-fees' ? 'Semester Fee Breakdown' : 'Consolidated Fee Matrix';

    XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);

    // Generate timestamped filename
    const dateStr = new Date().toISOString().split('T')[0];
    const filename = `BRDP_${sheetName.replace(/\s+/g, '_')}_${dateStr}.xlsx`;

    // Download file
    XLSX.writeFile(workbook, filename);
  } catch (err) {
    alert(`Export Error: ${err.message}`);
  }
}

function exportActivePreview() {
  exportToExcel(state.activeReportType);
}

// 4. Schema Inspector
async function loadSchemaForCollection(collName) {
  try {
    const res = await fetch(`/api/collections/${collName}/schema`);
    const data = await res.json();
    state.schemaData = data.schema;
    renderSchemaDiagram(collName, data.schema);
  } catch (err) {
    console.error('Error loading schema:', err);
  }
}

function renderSchemaDiagram(collName, schema) {
  const container = document.getElementById('schemaDiagramContainer');
  if (!container || !schema || !schema.fields) return;

  container.innerHTML = `
    <div class="schema-node" style="border-left-color: var(--accent-purple); background: var(--bg-card);">
      <span class="schema-node-name"><i data-lucide="database" style="width:16px; height:16px; margin-right:6px;"></i> ${collName}</span>
      <span class="badge badge-accent">Collection Root</span>
    </div>
    ${schema.fields.map(f => `
      <div class="schema-node" style="margin-left: 20px;">
        <div>
          <span class="schema-node-name">${f.name}</span>
          ${f.required ? '<span class="badge badge-accent" style="margin-left:8px; font-size:0.65rem;">Required</span>' : ''}
        </div>
        <span class="schema-node-type">${f.type}</span>
      </div>
    `).join('')}
  `;
  if (window.lucide) lucide.createIcons();
}

// 5. Document Explorer
async function loadExplorerDocuments(collName, page = 1, search = '') {
  try {
    state.page = page;
    const res = await fetch(`/api/collections/${collName}/documents?page=${page}&limit=${state.limit}&search=${encodeURIComponent(search)}`);
    const data = await res.json();

    state.documents = data.documents || [];
    renderExplorerTable();
  } catch (err) {
    console.error('Error loading documents:', err);
  }
}

function renderExplorerTable() {
  const header = document.getElementById('explorerTableHeader');
  const body = document.getElementById('explorerTableBody');
  if (!header || !body) return;

  if (state.documents.length === 0) {
    header.innerHTML = '<th>No Data</th>';
    body.innerHTML = '<tr><td class="text-muted p-4">No documents found in collection.</td></tr>';
    return;
  }

  const keys = Object.keys(state.documents[0]).slice(0, 6);
  header.innerHTML = keys.map(k => `<th>${k}</th>`).join('');
  body.innerHTML = state.documents.map(doc => `
    <tr>
      ${keys.map(k => `<td>${typeof doc[k] === 'object' ? JSON.stringify(doc[k]) : String(doc[k])}</td>`).join('')}
    </tr>
  `).join('');
}

// 6. Navigation Tabs Switcher
function initNavigation() {
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.addEventListener('click', () => {
      const tabId = btn.getAttribute('data-tab');
      switchTab(tabId);
    });
  });

  document.getElementById('schemaCollectionSelect').addEventListener('change', (e) => selectCollection(e.target.value));
  document.getElementById('explorerCollectionSelect').addEventListener('change', (e) => selectCollection(e.target.value));
}

function switchTab(tabId) {
  state.currentTab = tabId;
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));

  const navBtn = document.querySelector(`.nav-item[data-tab="${tabId}"]`);
  if (navBtn) navBtn.classList.add('active');

  const pane = document.getElementById(`tab-${tabId}`);
  if (pane) pane.classList.add('active');

  if (tabId === 'analytics') loadAnalyticsCharts();
}

function initToolbar() {
  const searchInput = document.getElementById('explorerSearchInput');
  let searchTimeout;
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      clearTimeout(searchTimeout);
      searchTimeout = setTimeout(() => {
        loadExplorerDocuments(state.activeCollection, 1, e.target.value);
      }, 300);
    });
  }
}

function initModals() {
  const connectModal = document.getElementById('connectModal');
  document.getElementById('btnConnectModal').addEventListener('click', () => connectModal.classList.add('show'));
  document.getElementById('btnCloseConnectModal').addEventListener('click', () => connectModal.classList.remove('show'));

  document.getElementById('btnSubmitConnect').addEventListener('click', async () => {
    const uri = document.getElementById('modalUriInput').value;
    const alertBox = document.getElementById('connectAlert');
    alertBox.className = 'alert-box alert-hidden';

    try {
      const res = await fetch('/api/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uri })
      });
      const data = await res.json();

      if (data.connected) {
        alertBox.className = 'alert-box success mt-3';
        alertBox.textContent = `Connected to Live MongoDB DB: ${data.dbName}`;
        setTimeout(() => {
          connectModal.classList.remove('show');
          fetchConnectionState();
          loadOverviewStats();
          previewReport(state.activeReportType);
        }, 1000);
      } else {
        alertBox.className = 'alert-box danger mt-3';
        alertBox.textContent = `Connection failed: ${data.error || 'Server unreachable'}`;
      }
    } catch (err) {
      alertBox.className = 'alert-box danger mt-3';
      alertBox.textContent = err.message;
    }
  });
}

async function loadAnalyticsCharts() {
  try {
    const res = await fetch('/api/analytics');
    const data = await res.json();
    renderChart('chartDept', 'doughnut', Object.keys(data.departmentDistribution), Object.values(data.departmentDistribution), [
      '#6366f1', '#a855f7', '#06b6d4', '#10b981', '#f59e0b'
    ]);
  } catch (err) {
    console.error('Error loading analytics:', err);
  }
}

function renderChart(canvasId, type, labels, dataPoints, colors) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  if (state.charts[canvasId]) state.charts[canvasId].destroy();

  state.charts[canvasId] = new Chart(ctx, {
    type: type,
    data: {
      labels: labels,
      datasets: [{ label: 'Count', data: dataPoints, backgroundColor: colors }]
    },
    options: { responsive: true, maintainAspectRatio: false }
  });
}
