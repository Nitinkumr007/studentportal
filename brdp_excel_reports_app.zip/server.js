const express = require('express');
const cors = require('cors');
const { MongoClient, ObjectId } = require('mongodb');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static('public'));

// Global MongoDB Connection State
let mongoClient = null;
let currentDb = null;
let currentDbName = 'brdp_portal';
let currentUri = process.env.DATABASE_URL || 'mongodb://localhost:27017/brdp_portal';
let isConnectedToLiveDb = false;
let connectionError = null;

// Initial Mock Dataset for BRDP Student Information System Sandbox
const mockData = {
  students: [
    {
      _id: "6501a1b2c3d4e5f678901001",
      rollNo: "BRDP2024001",
      fullName: "Aarav Sharma",
      fatherName: "Ramesh Sharma",
      address: "Civil Lines, Sitapur, UP",
      course: "B.Tech CSE",
      session: "2024-2025",
      currentSemester: 3,
      collegeCode: "BRDP",
      status: "Active",
      createdAt: "2024-07-15T10:00:00Z"
    },
    {
      _id: "6501a1b2c3d4e5f678901002",
      rollNo: "BRDP2024002",
      fullName: "Priya Verma",
      fatherName: "Sunil Verma",
      address: "Aliganj, Lucknow, UP",
      course: "B.Tech CSE",
      session: "2024-2025",
      currentSemester: 3,
      collegeCode: "BRDP",
      status: "Active",
      createdAt: "2024-07-16T11:15:00Z"
    },
    {
      _id: "6501a1b2c3d4e5f678901003",
      rollNo: "BRDP2024003",
      fullName: "Rohan Gupta",
      fatherName: "Anand Gupta",
      address: "Kalyanpur, Kanpur, UP",
      course: "BCA",
      session: "2024-2025",
      currentSemester: 2,
      collegeCode: "BRDP",
      status: "Active",
      createdAt: "2024-07-20T09:30:00Z"
    },
    {
      _id: "6501a1b2c3d4e5f678901004",
      rollNo: "BRDP2024004",
      fullName: "Ananya Mishra",
      fatherName: "Vikas Mishra",
      address: "Station Road, Sitapur, UP",
      course: "MCA",
      session: "2024-2025",
      currentSemester: 1,
      collegeCode: "BRDP",
      status: "Active",
      createdAt: "2024-07-22T14:20:00Z"
    },
    {
      _id: "6501a1b2c3d4e5f678901005",
      rollNo: "BRDP2024005",
      fullName: "Aditya Singh",
      fatherName: "Mahendra Singh",
      address: "Main Market, Lakhimpur Kheri, UP",
      course: "BBA",
      session: "2024-2025",
      currentSemester: 2,
      collegeCode: "BRDP",
      status: "Active",
      createdAt: "2024-07-25T16:45:00Z"
    }
  ],
  fee_ledgers: [
    // Aarav Sharma (Sem 1, Sem 2, Sem 3)
    { _id: "f101", studentId: "6501a1b2c3d4e5f678901001", rollNo: "BRDP2024001", studentName: "Aarav Sharma", semester: 1, totalAmount: 25000, paidAmount: 25000, status: "PAID", dueDate: "2023-08-30" },
    { _id: "f102", studentId: "6501a1b2c3d4e5f678901001", rollNo: "BRDP2024001", studentName: "Aarav Sharma", semester: 2, totalAmount: 25000, paidAmount: 25000, status: "PAID", dueDate: "2024-01-15" },
    { _id: "f103", studentId: "6501a1b2c3d4e5f678901001", rollNo: "BRDP2024001", studentName: "Aarav Sharma", semester: 3, totalAmount: 25000, paidAmount: 15000, status: "PARTIAL", dueDate: "2024-08-30" },

    // Priya Verma (Sem 1, Sem 2, Sem 3)
    { _id: "f201", studentId: "6501a1b2c3d4e5f678901002", rollNo: "BRDP2024002", studentName: "Priya Verma", semester: 1, totalAmount: 25000, paidAmount: 25000, status: "PAID", dueDate: "2023-08-30" },
    { _id: "f202", studentId: "6501a1b2c3d4e5f678901002", rollNo: "BRDP2024002", studentName: "Priya Verma", semester: 2, totalAmount: 25000, paidAmount: 18000, status: "PARTIAL", dueDate: "2024-01-15" },
    { _id: "f203", studentId: "6501a1b2c3d4e5f678901002", rollNo: "BRDP2024002", studentName: "Priya Verma", semester: 3, totalAmount: 25000, paidAmount: 0, status: "PENDING", dueDate: "2024-08-30" },

    // Rohan Gupta (Sem 1, Sem 2)
    { _id: "f301", studentId: "6501a1b2c3d4e5f678901003", rollNo: "BRDP2024003", studentName: "Rohan Gupta", semester: 1, totalAmount: 20000, paidAmount: 20000, status: "PAID", dueDate: "2023-08-30" },
    { _id: "f302", studentId: "6501a1b2c3d4e5f678901003", rollNo: "BRDP2024003", studentName: "Rohan Gupta", semester: 2, totalAmount: 20000, paidAmount: 10000, status: "PARTIAL", dueDate: "2024-01-15" },

    // Ananya Mishra (Sem 1)
    { _id: "f401", studentId: "6501a1b2c3d4e5f678901004", rollNo: "BRDP2024004", studentName: "Ananya Mishra", semester: 1, totalAmount: 30000, paidAmount: 0, status: "PENDING", dueDate: "2024-08-30" },

    // Aditya Singh (Sem 1, Sem 2)
    { _id: "f501", studentId: "6501a1b2c3d4e5f678901005", rollNo: "BRDP2024005", studentName: "Aditya Singh", semester: 1, totalAmount: 22000, paidAmount: 22000, status: "PAID", dueDate: "2023-08-30" },
    { _id: "f502", studentId: "6501a1b2c3d4e5f678901005", rollNo: "BRDP2024005", studentName: "Aditya Singh", semester: 2, totalAmount: 22000, paidAmount: 22000, status: "PAID", dueDate: "2024-01-15" }
  ],
  courses: [
    { _id: "c101", code: "CSE", name: "B.Tech Computer Science Engineering", duration: 4, totalSemesters: 8 },
    { _id: "c102", code: "BCA", name: "Bachelor of Computer Applications", duration: 3, totalSemesters: 6 },
    { _id: "c103", code: "MCA", name: "Master of Computer Applications", duration: 2, totalSemesters: 4 },
    { _id: "c104", code: "BBA", name: "Bachelor of Business Administration", duration: 3, totalSemesters: 6 }
  ],
  sessions: [
    { _id: "s101", name: "2024-2025" },
    { _id: "s102", name: "2023-2024" }
  ]
};

// Attempt MongoDB Connection
async function connectToMongo(uri) {
  try {
    if (mongoClient) {
      await mongoClient.close();
    }
    console.log(`Connecting to MongoDB URI: ${uri}`);
    mongoClient = new MongoClient(uri, { serverSelectionTimeoutMS: 3000 });
    await mongoClient.connect();
    
    const parsedUri = new URL(uri.startsWith('mongodb') ? uri : `mongodb://${uri}`);
    const pathnameDb = parsedUri.pathname ? parsedUri.pathname.replace('/', '') : '';
    currentDbName = pathnameDb || 'brdp_portal';
    
    currentDb = mongoClient.db(currentDbName);
    await currentDb.command({ ping: 1 });
    
    isConnectedToLiveDb = true;
    currentUri = uri;
    connectionError = null;
    console.log(`Successfully connected to Live MongoDB Database: ${currentDbName}`);
    return true;
  } catch (err) {
    console.warn(`MongoDB Connection Warning: ${err.message}`);
    isConnectedToLiveDb = false;
    connectionError = err.message;
    return false;
  }
}

connectToMongo(currentUri);

// Helper: Infer JSON Schema
function inferSchema(docs) {
  if (!docs || docs.length === 0) return { fields: [] };
  const fieldMap = {};
  const totalDocs = docs.length;

  docs.forEach(doc => {
    Object.keys(doc).forEach(key => {
      const val = doc[key];
      let type = typeof val;
      if (val === null) type = 'Null';
      else if (Array.isArray(val)) type = 'Array';
      else if (val instanceof Date || (typeof val === 'string' && !isNaN(Date.parse(val)) && val.includes('T'))) type = 'Date';
      else if (typeof val === 'string' && /^[0-9a-fA-F]{24}$/.test(val)) type = 'ObjectId';
      else if (type === 'object') type = 'Object';
      else if (type === 'string') type = 'String';
      else if (type === 'number') type = 'Number';
      else if (type === 'boolean') type = 'Boolean';

      if (!fieldMap[key]) {
        fieldMap[key] = { name: key, types: new Set([type]), count: 1, sampleValue: val };
      } else {
        fieldMap[key].types.add(type);
        fieldMap[key].count++;
      }
    });
  });

  const fields = Object.values(fieldMap).map(f => ({
    name: f.name,
    type: Array.from(f.types).join(' | '),
    presencePct: Math.round((f.count / totalDocs) * 100),
    required: f.count === totalDocs,
    sample: f.sampleValue
  }));

  return { fields, sampleCount: totalDocs };
}

// ─────────────────────────────────────────────
// EXCEL REPORTS API ENDPOINTS
// ─────────────────────────────────────────────

// 1. Student Master Data Report Endpoint
app.get('/api/reports/students', async (req, res) => {
  try {
    let studentList = [];
    if (isConnectedToLiveDb && currentDb) {
      studentList = await currentDb.collection('students').find().toArray();
    } else {
      studentList = mockData.students;
    }

    const report = studentList.map(s => ({
      "Roll No": s.rollNo || s.enrollmentNo || '--',
      "Full Name": s.fullName || s.name || '--',
      "Father Name": s.fatherName || (s.guardian ? s.guardian.name : '--'),
      "Course": s.course || '--',
      "Session": s.session || '2024-2025',
      "Current Semester": s.currentSemester || s.semester || 1,
      "College Code": s.collegeCode || 'BRDP',
      "Address": s.address ? (typeof s.address === 'object' ? `${s.address.city}, ${s.address.state}` : s.address) : '--',
      "Status": s.status || (s.isActive ? 'Active' : 'Inactive'),
      "Created Date": s.createdAt ? new Date(s.createdAt).toISOString().split('T')[0] : '--'
    }));

    res.json({ success: true, count: report.length, data: report });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 2. Semester-Wise Fees Breakdown Report Endpoint
app.get('/api/reports/semester-fees', async (req, res) => {
  try {
    let ledgers = [];
    let students = [];

    if (isConnectedToLiveDb && currentDb) {
      ledgers = await currentDb.collection('fee_ledgers').find().toArray();
      students = await currentDb.collection('students').find().toArray();
    } else {
      ledgers = mockData.fee_ledgers;
      students = mockData.students;
    }

    const studentMap = {};
    students.forEach(s => studentMap[String(s._id)] = s);

    const report = ledgers.map(l => {
      const student = studentMap[String(l.studentId)] || {};
      const total = Number(l.totalAmount || 0);
      const paid = Number(l.paidAmount || 0);
      const pending = Math.max(0, total - paid);

      return {
        "Roll No": l.rollNo || student.rollNo || '--',
        "Student Name": l.studentName || student.fullName || student.name || '--',
        "Course": student.course || '--',
        "Semester": `Semester ${l.semester}`,
        "Total Fee (₹)": total,
        "Paid Amount (₹)": paid,
        "Pending Amount (₹)": pending,
        "Fee Status": l.status || (pending === 0 ? 'PAID' : (paid > 0 ? 'PARTIAL' : 'PENDING')),
        "Due Date": l.dueDate ? new Date(l.dueDate).toISOString().split('T')[0] : '--'
      };
    });

    res.json({ success: true, count: report.length, data: report });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 3. Consolidated Semester-Wise Matrix Report Endpoint
app.get('/api/reports/consolidated-matrix', async (req, res) => {
  try {
    let students = [];
    let ledgers = [];

    if (isConnectedToLiveDb && currentDb) {
      students = await currentDb.collection('students').find().toArray();
      ledgers = await currentDb.collection('fee_ledgers').find().toArray();
    } else {
      students = mockData.students;
      ledgers = mockData.fee_ledgers;
    }

    // Map ledgers by studentId and semester
    const ledgerMap = {};
    ledgers.forEach(l => {
      const sid = String(l.studentId);
      if (!ledgerMap[sid]) ledgerMap[sid] = {};
      ledgerMap[sid][l.semester] = l;
    });

    const report = students.map(s => {
      const sid = String(s._id);
      const sLedgers = ledgerMap[sid] || {};

      let totalCourseFee = 0;
      let totalPaid = 0;
      let totalPending = 0;

      const row = {
        "Roll No": s.rollNo || s.enrollmentNo || '--',
        "Student Name": s.fullName || s.name || '--',
        "Course": s.course || '--',
        "Session": s.session || '2024-2025',
        "Current Semester": s.currentSemester || s.semester || 1
      };

      // Up to 6 Semesters matrix breakdown
      for (let sem = 1; sem <= 6; sem++) {
        const l = sLedgers[sem];
        const semFee = l ? Number(l.totalAmount || 0) : 0;
        const semPaid = l ? Number(l.paidAmount || 0) : 0;
        const semPending = l ? Math.max(0, semFee - semPaid) : 0;

        row[`Sem ${sem} Fee (₹)`] = semFee;
        row[`Sem ${sem} Paid (₹)`] = semPaid;
        row[`Sem ${sem} Pending (₹)`] = semPending;

        totalCourseFee += semFee;
        totalPaid += semPaid;
        totalPending += semPending;
      }

      row["Total Course Fee (₹)"] = totalCourseFee;
      row["Total Paid (₹)"] = totalPaid;
      row["Overall Pending Balance (₹)"] = totalPending;
      row["Overall Status"] = totalPending === 0 && totalCourseFee > 0 ? "PAID" : (totalPaid > 0 ? "PARTIAL" : "PENDING");

      return row;
    });

    res.json({ success: true, count: report.length, data: report });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Standard REST API Routes
app.post('/api/connect', async (req, res) => {
  const { uri } = req.body;
  if (!uri) return res.status(400).json({ error: 'MongoDB URI is required' });

  const success = await connectToMongo(uri);
  res.json({
    connected: isConnectedToLiveDb,
    uri: currentUri,
    dbName: currentDbName,
    mode: isConnectedToLiveDb ? 'LIVE_MONGODB' : 'SANDBOX_MOCK',
    error: connectionError
  });
});

app.get('/api/db/stats', async (req, res) => {
  try {
    if (isConnectedToLiveDb && currentDb) {
      const stats = await currentDb.stats();
      const collections = await currentDb.listCollections().toArray();
      res.json({
        dbName: currentDbName,
        mode: 'LIVE_MONGODB',
        collectionsCount: collections.length,
        documentsCount: stats.objects || 0,
        dataSizeMB: (stats.dataSize / (1024 * 1024)).toFixed(2),
        storageSizeMB: (stats.storageSize / (1024 * 1024)).toFixed(2),
        indexesCount: stats.indexes || 0,
        connectedUri: currentUri
      });
    } else {
      let totalDocs = 0;
      Object.values(mockData).forEach(arr => totalDocs += arr.length);
      res.json({
        dbName: currentDbName,
        mode: 'SANDBOX_MOCK',
        collectionsCount: Object.keys(mockData).length,
        documentsCount: totalDocs,
        dataSizeMB: (0.45).toFixed(2),
        storageSizeMB: (1.20).toFixed(2),
        indexesCount: 14,
        connectedUri: currentUri
      });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/collections', async (req, res) => {
  try {
    if (isConnectedToLiveDb && currentDb) {
      const collectionsRaw = await currentDb.listCollections().toArray();
      const collections = await Promise.all(collectionsRaw.map(async c => {
        const count = await currentDb.collection(c.name).countDocuments();
        return { name: c.name, count, type: 'collection' };
      }));
      res.json({ collections });
    } else {
      const collections = Object.keys(mockData).map(key => ({
        name: key,
        count: mockData[key].length,
        type: 'collection'
      }));
      res.json({ collections });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/collections/:name/schema', async (req, res) => {
  const collName = req.params.name;
  try {
    let docs = [];
    if (isConnectedToLiveDb && currentDb) {
      docs = await currentDb.collection(collName).find().limit(100).toArray();
    } else {
      docs = mockData[collName] || [];
    }
    const schema = inferSchema(docs);
    res.json({ collection: collName, schema, documentCount: docs.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/collections/:name/documents', async (req, res) => {
  const collName = req.params.name;
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 20;
  const search = req.query.search || '';

  try {
    if (isConnectedToLiveDb && currentDb) {
      const query = search ? { $text: { $search: search } } : {};
      const total = await currentDb.collection(collName).countDocuments(query);
      const docs = await currentDb.collection(collName)
        .find(query)
        .skip((page - 1) * limit)
        .limit(limit)
        .toArray();
      res.json({ documents: docs, total, page, totalPages: Math.ceil(total / limit) });
    } else {
      let docs = mockData[collName] ? [...mockData[collName]] : [];
      if (search) {
        const searchLower = search.toLowerCase();
        docs = docs.filter(d => JSON.stringify(d).toLowerCase().includes(searchLower));
      }
      const total = docs.length;
      const paginatedDocs = docs.slice((page - 1) * limit, page * limit);
      res.json({ documents: paginatedDocs, total, page, totalPages: Math.ceil(total / limit) });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`🚀 BRDP Student & Fee Excel Report Generator Server`);
  console.log(`URL: http://localhost:${PORT}`);
  console.log(`====================================================`);
});
